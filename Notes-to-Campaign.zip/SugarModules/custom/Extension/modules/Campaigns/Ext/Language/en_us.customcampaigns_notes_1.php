<?php
// WARNING: The contents of this file are auto-generated.
?>
<?php
// Merged from custom/Extension/modules/Campaigns/Ext/Language/en_us.customcampaigns_notes_1.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_CAMPAIGNS_NOTES_1_FROM_NOTES_TITLE'] = 'Notes';
$mod_strings['LBL_CAMPAIGNS_NOTES_1_FROM_CAMPAIGNS_TITLE'] = 'Notes';

?>
<?php
// Merged from custom/Extension/modules/Campaigns/Ext/Language/temp.php

//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_CAMPAIGNS_NOTES_1_FROM_NOTES_TITLE'] = 'Notes';
$mod_strings['LBL_CAMPAIGNS_NOTES_1_FROM_CAMPAIGNS_TITLE'] = 'Notes';

?>
