<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/campaigns_notes_1MetaData.php');

?>