<?php
// created: 2018-07-25 22:44:36
$dictionary["Campaign"]["fields"]["campaigns_notes_1"] = array (
  'name' => 'campaigns_notes_1',
  'type' => 'link',
  'relationship' => 'campaigns_notes_1',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'vname' => 'LBL_CAMPAIGNS_NOTES_1_FROM_CAMPAIGNS_TITLE',
  'id_name' => 'campaigns_notes_1campaigns_ida',
  'link-type' => 'many',
  'side' => 'left',
);
