<?php
//auto-generated file DO NOT EDIT
$layout_defs['Campaigns']['subpanel_setup']['campaigns_notes_1']['override_subpanel_name'] = 'Campaign_subpanel_campaigns_notes_1';
?>